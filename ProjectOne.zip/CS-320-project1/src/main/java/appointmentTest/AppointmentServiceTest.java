package appointmentTest;

//import necessary libraries
import java.util.Calendar;
import java.util.Date;
import java.util.ArrayList;
import appointment.Appointment;
import appointment.AppointmentService;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


public class AppointmentServiceTest {
	
	//house keeping date
	private Date Date(int i, int january, int j) {
		return null;
	}
	//test to make sure an appointment is added correctly
	@Test
	@DisplayName("add appointment")
	void testAddApt() {
		AppointmentService service = new AppointmentService();
		service.addApt(Date(2024, Calendar.JANUARY, 1), "Type");
		service.displayAptList();
		assertNotNull(service.getApt("3"), "Appointment was not added.");
	}
	//test to change the date of an appointment correctly
	@Test
	@DisplayName("change date of appointment")
	void testChangeDate() {
		AppointmentService service = new AppointmentService();
		service.addApt(Date(2024, Calendar.JANUARY, 1), "Type");
		service.changeAptDate(Date(2025, Calendar.OCTOBER, 31), "0");
		service.displayAptList();
		assertEquals(Date(2025, Calendar.OCTOBER, 31), service.getApt("0").getAptDate(), "Date was not changed");
		
	}
	//test to change the type of appointment
	@Test
	@DisplayName("change type of appointment.")
	void testChangeAptType() {
		AppointmentService service = new AppointmentService();
		service.addApt(Date(2024, Calendar.JANUARY, 1), "Type");
		service.changeAptType("new type of appointment", "1");
		service.displayAptList();
		assertEquals("Updated Type", service.getApt("1").getAptType(), "Appointment type was not changed.");
	}
	//test to delete an appointment
	//a second list is made to compare and ensure deletion
	@Test
	@DisplayName("check appointment deletion.")
	void testDeleteApt() {
		AppointmentService service = new AppointmentService();
		service.addApt(Date(2024, Calendar.JANUARY, 1), "Type");
		service.deleteApt("2");
		ArrayList<Appointment> aptListEmpty = new ArrayList<Appointment>();
		service.displayAptList();
		assertEquals(service.aptList, aptListEmpty, "The appointment was not deleted.");
	}

}
