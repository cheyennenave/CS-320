package appointmentTest;

import java.util.Calendar;
import java.util.Date;
import appointment.Appointment;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertNotNull;


public class AppointmentTest {

	private Date Date(int i, int january, int j) {
		return null;
	}
	
	//test to check the length of the appointment ID
	@Test
	@DisplayName("Appointment ID has to remain under 10 characters.")
	void testAptLength() {
		Appointment appointment = new Appointment(Date(2024, Calendar.JANUARY, 1), "Type");
		if (appointment.getAptID().length() > 10) {
			fail("Appointment ID is too long");
		}
	}
	
	//test to check the length of the type of appointment
	@Test
	@DisplayName("Appointment Type has to remain under 50 characters.")
	void testAptTypeLength() {
		Appointment appointment = new Appointment(Date(2024, Calendar.JANUARY, 1), "This type of appointment is entirely too long0123456789");
		if (appointment.getAptType().length() > 50) {
			fail("Appointment Type is too long");
		}
	}
	
	//test to make sure the appointment isn't back-dated
	@Test
	@DisplayName("Appointment Date has to be after today's date")
	void testAptDate() {
		Appointment appointment = new Appointment(Date(2025, Calendar.OCTOBER, 1), "Type");
		if (appointment.getAptDate().before(new Date())) {
			fail("Appointment Date is before today's date.");
		}
	}
	
	//test to make sure the date is not empty
	@Test
	@DisplayName("Date cannot be empty")
	void testAptDateNotNull() {
		Appointment appointment = new Appointment(null, "Type");
		assertNotNull(appointment.getAptDate(), "Appointment Date was empty.");
	}
	
	//test to make sure the appointment type is not empty
	@Test
	@DisplayName("Appointment Type cannot be empty")
	void testAptTypeNotNull() {
		Appointment appointment = new Appointment(Date(2024, Calendar.JANUARY, 1), null);
		assertNotNull(appointment.getAptType(), "Appointment Type was empty.");
	}
}