package contactTest;

import org.junit.jupiter.api.Test;

import contact.Contact;

import org.junit.jupiter.api.DisplayName;
import static org.junit.Assert.fail;
import static org.junit.Assert.assertNotNull;


	public class ContactTest {
		//Test to check and see how many characters the Contact ID has. 
		//If it has more than 10, the test will fail.
		@Test
		@DisplayName("ID has too many characters.")
		void testIdTooLong() {
			Contact contact = new Contact("id", "firstName", "lastName", "phoneNumber", "address");
			if(contact.getId().length()>10) {
				fail("ID has too many characters.");
			}
		}
		//Test to check character count for first name.
		//If it/s longer than 10, the test will fail.
		@Test
		@DisplayName("First Name has too many characters.")
		void testFirstNameTooLong() {
			Contact contact = new Contact("id", "Luke Skywalker", "lastName", "phoneNumber", "address");
			if(contact.getFirstName().length()>10) {
				fail("First Name has too many characters.");
			}
		}
		//Test to check character count for last name.
		//If it's longer than 10, the test will fail.
		@Test
		@DisplayName("Last Name has too many characters.")
		void testLastNameTooLong() {
			Contact contact = new Contact("id", "firstName", "Luke Skywalker", "phoneNumber", "address");
			if(contact.getLastName().length()>10) {
				fail("Last Name has too many characters.");
			}
		}
		//Test to check character count for phone number.
		//If the phone number doesn't have exactly 10 characters, the test will fail.
		@Test
		@DisplayName("Phone number has to have 10 numbers.")
		void testPhoneNumberLength() {
			Contact contact = new Contact("id", "firstName", "lastName", "123456789011", "address");
			if(contact.getPhoneNumber().length()!=10) {
				fail("Phone number has to have 10 numbers.");
			}
		}
		//Test to check character count of address.
		//if there are more than 30 characters, the test will fail
		@Test
		@DisplayName("Address has too many characters")
		void testAddressLength() {
			Contact contact = new Contact("id", "firstName", "lastName", "phoneNumber", "123 Kokiri Forest Hyrule Kingdom 00000");
			if(contact.getAddress().length()>30) {
				fail("Address has too many characters");
			}
		}
		//Test to make sure first name isn't empty.
		//if it is null, the test will fail.
		@Test
		@DisplayName("First name can't be empty")
		void testFirstNameEmpty() {
			Contact contact = new Contact("id", null, "lastName", "phoneNumber", "address");
			assertNotNull(contact.getFirstName(), "First name is empty");
		}
		//Test to make sure last name isn't empty.
		//if it is null, the test will fail.
		@Test
		@DisplayName("Last name can't be empty")
		void testLastNameEmpty() {
			Contact contact = new Contact("id", "firstName", null, "phoneNumber", "address");
			assertNotNull(contact.getLastName(), "Last name is empty.");
		}
		//Test to make sure the phone number isn't empty
		//if it is null, the test will fail
		@Test
		@DisplayName("Phone number can't be empty")
		void testPhoneNumberEmpty() {
			Contact contact = new Contact("id", "firstName", "lastName", null, "address");
			assertNotNull(contact.getPhoneNumber(), "Phone number is empty.");
		}
		//Test to make sure the address isn't empty
		//if it is null, the test will fail
		@Test
		@DisplayName("Address can't be empty")
		void testAddressEmpty() {
			Contact contact = new Contact("id", "firstName", "lastName", "phoneNumbr", null);
			assertNotNull(contact.getAddress(), "Address is empty.");
		}
	}
	
