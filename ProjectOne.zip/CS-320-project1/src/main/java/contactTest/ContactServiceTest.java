package contactTest;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import contact.ContactService;


public class ContactServiceTest {

	
	@Test
	@DisplayName("Testing first name change")
	void testChangeFirstName() {
		ContactService service = new ContactService();
		service.addContact("1","Kokiri", "Link", "01234567890", "111 Kokiri Forest");
		service.changeFirstName("Sir", "1");
		service.showContacts("", "", "", "", "");
		assertEquals("Sir", service.getContact("1").getFirstName(), "First name hasn't changed.");
	}

	@Test
	@DisplayName("Testing last name change")
	void testChangeLastName() {
		ContactService service = new ContactService();
		service.addContact("1", "Kokiri", "Link", "01234567890", "111 Kokiri Forest");
		service.changeLastName("Boy", "1");
		service.showContacts("", "", "", "", "");
		assertEquals("Boy", service.getContact("1").getLastName(), "Last name hasn't changed.");
	}

	@Test
	@DisplayName("Testing phone number change")
	void testChangePhoneNumber() {
		ContactService service = new ContactService();
		service.addContact("1", "Kokiri", "Link", "01234567890", "111 Kokiri Forest");
		service.changePhoneNumber("7775554321", "1");
		service.showContacts("", "", "", "", "");
		assertEquals("7775554321", service.getContact("1").getPhoneNumber(), "Phone number hasn't changed.");
	}

	@Test
	@DisplayName("Testing address change.")
	void testChangeAddress() {
		ContactService service = new ContactService();
		service.addContact("1", "Kokiri", "Link", "01234567890", "111 Kokiri Forest");
		service.changeAddress("777 Hyrule Castle", "1");
		service.showContacts("", "", "", "", "");
		assertEquals("777 Hyrule Castle", service.getContact("1").getAddress(), "Address hasn't changed.");
	}

	@Test
	@DisplayName("Testing contact deletion.")
	void testDeleteContact() {
		ContactService service = new ContactService();
		service.addContact("1", "Kokiri", "Link", "1234567890", "111 Kokiri Forest");
		service.deleteContact("1");
		service.showContacts("", "", "", "", "");
		assertEquals(service.contactList, "The contact was not deleted.");
	}

	

	@Test
	@DisplayName("Testing contact addition.")
	void testAddContact() {
		ContactService service = new ContactService();
		service.addContact("1", "Kokiri", "Link", "1234567890", "111 Kokiri Forest");
		service.showContacts("", "", "", "", "");
		assertNotNull(service.getContact("2"), "Contact was not added.");
	}

}