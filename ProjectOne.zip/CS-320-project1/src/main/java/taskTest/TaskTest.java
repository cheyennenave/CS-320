package taskTest;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.DisplayName;
import static org.junit.Assert.fail;

import task.Task;

public class TaskTest {

	//test to check the length of an ID for a task. 
	//If the ID is too long, the test fails.
	@Test
	@DisplayName("Task ID cannot exceed 10 characters")
	void testTaskIdLength() {
		Task task = new Task("Name", "Type");
		if(task.getTaskId().length() > 10) {
			fail("Task ID is too long.");
		}
	}
	
	//test to check the length of the name of a task.
	//the test will fail if there are more than 20 characters
	@Test
	@DisplayName("Task Name cannot exceed 20 characters")
	void testTaskNameLength() {
		Task task = new Task("Operation: Save Hyrule!", "Description");
		if (task.getTaskName().length() > 20) {
			fail("Task Name is too long.");
		}
	}
	
	//test to check the length of the type entered for a task.
	//the test will fail if there more than 50 characters.
	@Test
	@DisplayName("Task Type cannot exceed 50 characters")
	void testTaskTypeLength() {
		Task task = new Task("Name", "Your task is to save Hyrule Kingdom from Ganondorf!!!");
		if(task.getTaskType().length() > 50) {
			fail("Task Type is too long.");
		}
	}
	
	@Test
	@DisplayName("Task Name cannot be empty")
	void testTaskNameNotNull() {
		Task task = new Task(null, "Type");
		assertNotNull(task.getTaskName(), "Task Name was empty.");
	}
	
	@Test
	@DisplayName("Task Type cannot be empty")
	void testTaskTypeNotNull() {
		Task task = new Task("Name", null);
		assertNotNull(task.getTaskType(), "Task Description was empty.");
	}
	
}
