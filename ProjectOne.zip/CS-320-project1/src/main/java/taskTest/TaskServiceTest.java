package taskTest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import task.TaskService;

class taskServiceTest {
	//test to make sure task name can be edited.
	//test will fail if it does not change.
	@Test
	@DisplayName("Change task name")
	void testChangeTaskName() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "Type");
		service.changeTaskName("Different Task Name", "1");
		service.displayTasks("","","");
		assertEquals("Different Task Name", service.getTask("1").getTaskName(), "Task name unchanged.");
	}
	
	//test to make sure task type can be edited.
	//test will fail if it does not change.
	@Test
	@DisplayName("Test to change task type.")
	void testChangeTaskType() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "type");
		service.changeTaskType("Changed type", "2");
		service.displayTasks("","","");
		assertEquals("Changed type", service.getTask("2").getTaskType(), "Task type unchanged.");
	}
	
	//test to make sure task can be deleted
	@Test
	@DisplayName("test to delete task")
	void testDeleteTask() {
		TaskService service = new TaskService();
		service.addTask("Task name", "type");
		service.deleteTask("0");
		assertEquals(service.taskList, "The task was not deleted.");
	}
	//test to make sure task can be added
	@Test
	@DisplayName("test to add task.")
	void testAddTask() {
		TaskService service = new TaskService();
		service.addTask("Task Name", "type");
		service.displayTasks("","","");
		assertNotNull(service.getTask("3"), "Task was not added.");
	}
}
