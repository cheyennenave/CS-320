package task;

import java.util.ArrayList;

public class TaskService {
	//create List to hold tasks
	public ArrayList<Task> taskList = new ArrayList<Task>();
	
	
	//get task
	public Task getTask(String taskId){
    	for(int i = 0; i < taskList.size(); i++){
        	if(taskList.get(i).getTaskId().equals(taskId)){
            	return taskList.get(i);
            }
        }
      return null;
    }
	
	
	//Add a new task to the list
	public void addTask(String taskName, String taskType) {
		Task task = new Task(taskName, taskType);
		taskList.add(task);
	}
	
	//Delete a task from the list
	public void deleteTask(String taskId) {
		for(int i = 0; i < taskList.size(); i++) {
		if(taskList.get(i).getTaskId().equals(taskId)) {
			taskList.remove(i);
			break;
			}	
		}
	}
	
	//Change task name
	public void changeTaskName(String changedName, String taskId) {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getTaskId().equals(taskId)) {
				taskList.get(i).setTaskName(changedName);
				break;
			}
		}
	}
	//Change task type
	public void changeTaskType(String changedType, String taskId) {
		for(int i = 0; i < taskList.size(); i++) {
			if(taskList.get(i).getTaskId().equals(taskId)) {
				taskList.get(i).setTaskType(changedType);
				break;
			}
		}
	}
	//Display task list
	public void displayTasks(String taskId, String taskName, String taskType) {
		for(int i = 0; i < taskList.size(); i++) {
			if (taskList.get(i).getTaskId().equals(taskId)){
				System.out.println("Task ID: " + taskList.get(i).getTaskId());
				System.out.println("Task Name: " + taskList.get(i).getTaskName());
				System.out.println("Task Type: " + taskList.get(i).getTaskType());
			}
		}
	}
}
