package task;

public class Task {
	
	//house keeping variables
	private String taskId;
	private String taskType;
	private String taskName;
	private static long idCounter = 0;
	
	//create unique ID that cannot be changed
	public static synchronized String createId() {
		return String.valueOf(idCounter++);
	}
	
	
	public Task (String taskName, String taskType) {
		
		this.taskId = String.valueOf(idCounter++); //increments generated IDs so no same number is used
		
		//ensure that task name is not empty and is less than 20 characters
		if (taskName ==null || taskName.isEmpty()) {
			this.taskName = "Empty";
		}
		else if(taskName.length() > 20) {
			this.taskName = taskName.substring(0,20);
		}
		else {
			this.taskName = taskName;
		}
		
		//ensure that task type is not empty and is less than 50 characters
		if(taskType == null || taskType.isEmpty()) {
			this.taskType = "Empty";
		}
		else if(taskType.length() > 50) {
			this.taskType = taskType.substring(0,50);
		}
		else {
			this.taskType = taskType;
		}
	}
	//getters
	public String getTaskId() {
		return taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskType() {
		return taskType;
	}
	
	//setter for name
	public void setTaskName(String taskName) {
		if(taskName == null|| taskName.isEmpty()) {
			this.taskName = "Empty";
		}
		else if(taskName.length() > 20) {
			this.taskName = taskName.substring(0, 20);
		}
		else {
			this.taskName = taskName;
		}
	}
	//setter for type
	public void setTaskType(String taskType) {
		if(taskType == null || taskType.isEmpty()) {
			this.taskType = "Empty";
		}
		else if(taskType.length() > 50) {
			this.taskType = taskType.substring(0,50);
		}
		else {
			this.taskType = taskType;
		}
	}
}