package appointment;

//import necessary libraries
import java.util.Date;
import java.util.ArrayList;


public class AppointmentService {
	//create list for appointments to be stored
	public ArrayList<Appointment> aptList = new ArrayList<Appointment>();
	
	//add a new appointment
	public void addApt(Date aptDate, String aptType) {
		Appointment appointment = new Appointment(aptDate, aptType);
		aptList.add(appointment);
	}
	
	//return an appointment upon search
	public Appointment getApt(String aptID) {
		Appointment appointment = new Appointment(null, null);
		for (int i = 0; i < aptList.size(); i++) {
			if (aptList.get(i).getAptID().contentEquals(aptID)) {
				appointment = aptList.get(i);
			}
		}
		return appointment;
		
	}
	
	//delete the appointment by ID
	public void deleteApt(String aptID) {
		for (int i = 0; i < aptList.size(); i++) {
			if (aptList.get(i).getAptID().equals(aptID)) {
				aptList.remove(i);
				break;
			}
		}
	}
	
	//change the appointment date
	public void changeAptDate(Date newDate, String aptID) {
		for(int i = 0; i < aptList.size(); i++) {
			if (aptList.get(i).getAptID().equals(aptID)) {
				aptList.get(i).setAptDate(newDate);
				break;
			}
		}
	}
	
	//change or update the appointment type
	public void changeAptType(String changedApt, String aptID) {
		for (int i = 0; i < aptList.size(); i++) {
			if (aptList.get(i).getAptID().equals(aptID)) {
				aptList.get(i).setAptType(changedApt);
				break;
			}
		}
	}
	
	//display appointments
	public void displayAptList() {
		for(int i = 0; i < aptList.size(); i++) {
			System.out.println("Appointment ID: " + aptList.get(i).getAptID());
			System.out.println("Appointment Date: " + aptList.get(i).getAptDate());
			System.out.println("Appointment Type: " + aptList.get(i).getAptType());
		}
	}
}
