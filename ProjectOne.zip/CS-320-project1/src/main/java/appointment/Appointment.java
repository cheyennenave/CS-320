package appointment;

//import necessary libraries
import java.util.Calendar;
import java.util.Date;

public class Appointment {
	//set house keeping variables
	private String aptID;
	private Date aptDate;
	private String aptType;

	
	@SuppressWarnings("deprecation") // date is deprecated - this suppresses the warnings
	public Appointment(Date aptDate, String aptType) {
		//if the date for the appointment is null, it will be set to January 1st, 2024
		//otherwise it will accept the date as long as it's after the current date
		if(aptDate == null) {
			this.aptDate = new Date(2024, Calendar.JANUARY, 1);
		}
		else if(aptDate.before(new Date())) {
			throw new IllegalArgumentException("Date must be after today's date.");
		}
		else {
			this.aptDate = aptDate;
		}
		
		//if the appointment description is empty, it will be filled as "empty".
		//it will be set with a 50 character max
		if(aptType == null || aptType.isEmpty()) {
			this.aptType = "empty";
		}
		else if(aptType.length() > 50) {
			this.aptType = aptType.substring(0,50);
		}
		else {
			this.aptType = aptType;
		}
	}
	
	//getters
	public String getAptID() {
		return aptID;
	}
	
	public Date getAptDate() {
		return aptDate;
	}
	
	public String getAptType() {
		return aptType;
	}
	
	//setters
	@SuppressWarnings("deprecation")
	public void setAptDate(Date aptDate) {
		if (aptDate == null) {
			aptDate = new Date(2024, Calendar.JANUARY, 1);
		} else if (aptDate.before(new Date())) {
			throw new IllegalArgumentException("Date must be after today's date.");
		} else {
			this.aptDate = aptDate;
		}
	}
	
	public void setAptType(String aptType) {
		if (aptType == null || aptType.isEmpty()) {
			this.aptType = "empty";
		} else if (aptType.length() > 50) {
			this.aptType = aptType.substring(0, 50);
		} else {
			this.aptType = aptType;
		}
	}
}