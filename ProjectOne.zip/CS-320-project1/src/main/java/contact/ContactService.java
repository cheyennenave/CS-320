package contact;

import java.util.ArrayList;

public class ContactService {
	//create list to hold contacts
	public ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	//constructor to add a new contact
	public void addContact(String id,String firstName, String lastName, String phoneNumber, String address) {
		Contact contact = new Contact(id, firstName, lastName, phoneNumber, address);
		contactList.add(contact);
	}
	//return contact based on ID
	public Contact getContact(String id) {
		Contact contact = null;
		for(int i = 0; i < contactList.size(); i++) {
			if (contactList.get(i).getId().equals(id)) {
				contact = contactList.get(i);
			}
			else {
				System.out.println("Contact not found. Please enter a valid ID.");
			}
		}
		return contact;
	}
	
	//updating first name
	public void changeFirstName(String amendedFirstName, String id) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setFirstName(amendedFirstName);
				break;
			}
			if(!contactList.get(i).getId().equals(id)) {
				System.out.println("Invalid Contact. Please try again.");
			}
				
		}
	}
	
	//updating last name
	public void changeLastName(String amendedLastName, String id) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setLastName(amendedLastName);
				break;
			}
			if(!contactList.get(i).getId().equals(id)) {
				System.out.println("Invalid Contact. Please try again.");
			}
					
		}
	}
		
	//updating phone number
	public void changePhoneNumber(String amendedPhoneNumber, String id) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setPhoneNumber(amendedPhoneNumber);
			break;
			}
			if(!contactList.get(i).getId().equals(id)) {
				System.out.println("Invalid Contact. Please try again.");
			}					
		}
	}
	//updating address
	public void changeAddress(String amendedAddress, String id) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.get(i).setAddress(amendedAddress);
				break;
			}
			if(!contactList.get(i).getId().equals(id)) {
				System.out.println("Invalid Contact. Please try again.");
			}					
		}			
	}
		
	//delete contacts
	public void deleteContact(String id) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				contactList.remove(i);
			}
		}
	}
	//show contacts
	public void showContacts(String id, String firstName, String lastName, String phoneNumber, String address) {
		for(int i = 0; i < contactList.size(); i++) {
			if(contactList.get(i).getId().equals(id)) {
				System.out.println("Contact ID: " + id);
				System.out.println("First Name: " + firstName);
				System.out.println("Last Name: " + lastName);
				System.out.println("Phone: " + phoneNumber);
				System.out.println("Address: " + address);
			}
		}
	}
}