package contact;

public class Contact {

	//initialize housekeeping variables
	private String id;
	private String firstName;
	private String lastName;
	private String phoneNumber;
	private String address;
	
	
	public Contact(String id, String firstName, String lastName, String phoneNumber, String address) {
		//ensures id cannot exceed 10 characters
		if(id == null || id.length()>10) {
			throw new IllegalArgumentException("Invalid ID. ID can only include up to 10 characters.");
		}
		//ensures first name does not exceed 10 characters
		if(firstName == null || firstName.length()>10) {
			throw new IllegalArgumentException("Name is too long");
		}
		//ensures last name does not exceed 10 characters
		if(lastName == null || lastName.length()>10) {
			throw new IllegalArgumentException("Name is too long");
		}
		//ensures phone number is exactly 10 characters; no more, no less
		if(phoneNumber == null || phoneNumber.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number. Please enter a 10-digit number.");
		}
		//ensures address is entered under 30 characters
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Address is too long. Reminder: Please stay under 30 characters.");
		}

		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	
	//getters
	public String getId() {
		return id;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public String getAddress() {
		return address;
	}
	
	
	//setters
	public void setId(String id) {
		this.id = id;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
